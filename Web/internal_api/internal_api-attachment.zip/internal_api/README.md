# internal_api

基于 Rust 编写的 Search API

注意:
1. Flag 格式为 `nctf{[GUID]}`, 例如: `nctf{f8959e21-d76c-4393-8b2a-7349cedef9f6}`
2. 请确保你的 EXP 在本地环境中能打通 (拿到 Flag), 然后再去开远程环境
3. 在测试本地环境时, 请通过 `http://web:8000` 访问 Web 服务
3. 在打远程环境时, 请通过 `http://127.0.0.1:8000` 访问 Web 服务
