# sqlmap-master

你是 sqlmap 大师吗?

(靶机无法访问外网)